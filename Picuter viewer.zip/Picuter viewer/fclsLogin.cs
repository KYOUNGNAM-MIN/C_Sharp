﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Picuter_viewer
{
    public partial class fclsLogin : Form
    {
        public fclsLogin()
        {
            InitializeComponent();
        }

        private void fclsLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if(txtUserName.Text == "민경남")
            {
                MessageBox.Show("좋아요");
            }
            else
            {
                MessageBox.Show("싫어요");
            }
            
        }

        
    }
}
