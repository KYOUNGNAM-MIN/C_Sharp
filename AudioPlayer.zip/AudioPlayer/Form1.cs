﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AudioPlayer
{

    public partial class Form1 : Form
    {
        [DllImport("winmm.dll")]
        private static extern long mciSendString(string strCommand, StringBuilder
            strReturn, int iReturnLength, IntPtr hwndCallback);

        private long Len; //음악파일의 전체길이 (시간)

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void pauseMp3(string path)
        {
            timer1.Enabled = false;

        }
        private void playMp3(string path)
        {
            string commandString = "open \"" + path + "\" type mpegvideo alias media";
            mciSendString(commandString, null, 0, IntPtr.Zero);

            StringBuilder strReturn = new StringBuilder(128);
            mciSendString("status media length", strReturn, 128, IntPtr.Zero);

            Len = Convert.ToInt32(strReturn.ToString());
            timer1.Enabled = true;

            commandString = "play media notify";
            mciSendString(commandString, null, 0, IntPtr.Zero);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            playMp3(dlg.FileName);
        }
        
        private void btnStop_Click(object sender, EventArgs e)
        {
            pauseMp3(dlg.FileName);
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            playMp3(dlg.FileName);
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            dlg.Filter = "Mp3 Files|*.mp3";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dlg.FileName;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string commandString = "status media position";
            StringBuilder strReturn = new StringBuilder(128);
            mciSendString(commandString, strReturn, 128, IntPtr.Zero);

            label1.Text = "음악진행률:" + Convert.ToInt32(strReturn.ToString()) * 100 / Len + "%재생중";

            //프로그래스 바로 진행류류 표시
            progressBar1.Maximum = 100;
            progressBar1.Minimum = 0;

            progressBar1.Value = Convert.ToInt32(Convert.ToInt32(strReturn.ToString()) * 100 / Len);

        }
    }
}
