﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Picuter_viewer
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            picShowPicture.SizeMode = PictureBoxSizeMode.StretchImage;

        }

        private void btnSelectPicture_Click(object sender, EventArgs e)
        {
            if (ofdSelectPicture.ShowDialog() == DialogResult.OK)
            {
                picShowPicture.Image = Image.FromFile(ofdSelectPicture.FileName);
                this.Text = string.Concat("Picture Viewer(" + ofdSelectPicture.FileName + ")");
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnSelectPicture_MouseLeave(object sender, EventArgs e)
        {
            btnSelectPicture.BackColor = Color.Blue;
            labelx.Text = "";
            labely.Text = "";
        }

        private void btnSelectPicture_MouseEnter(object sender, EventArgs e)
        {
            btnSelectPicture.BackColor = Color.Red;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics objGraphics = null;
            objGraphics = this.CreateGraphics();
            objGraphics.Clear(SystemColors.Control);
            objGraphics.DrawRectangle(Pens.Red,
            picShowPicture.Left - 1, picShowPicture.Top - 1,
            picShowPicture.Width + 1, picShowPicture.Height + 1);
            objGraphics.Dispose();
        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            this.Width = this.Width + 20;
            this.Height = this.Height + 20;
        }
    
        private void btnMinus_Click(object sender, EventArgs e)
        {
            this.Width = this.Width - 20;
            this.Height = this.Height - 20;
        }

        private void picShowPicture_MouseMove(object sender, MouseEventArgs e)
        {
            labelx.Text = "X: " + e.X.ToString();
            labely.Text = "Y: " + e.Y.ToString();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            labelx.Text = "";
            labely.Text = "";
        }

        private void Opt_Click(object sender, EventArgs e)
        {
            frmOptions frmOptionsDialog = new Picuter_viewer.frmOptions();
            frmOptionsDialog.Show();
        }

        private void login_Click(object sender, EventArgs e)
        {
            
            fclsLogin objLogin = new Picuter_viewer.fclsLogin();
            objLogin.Show();
            
        }
    }
}
