﻿namespace Picuter_viewer
{
    partial class frmOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOptions));
            this.OptCls = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // OptCls
            // 
            this.OptCls.Location = new System.Drawing.Point(13, 203);
            this.OptCls.Name = "OptCls";
            this.OptCls.Size = new System.Drawing.Size(75, 23);
            this.OptCls.TabIndex = 0;
            this.OptCls.Text = "Close";
            this.OptCls.UseVisualStyleBackColor = true;
            this.OptCls.Click += new System.EventHandler(this.OptCls_Click);
            // 
            // frmOptions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(382, 253);
            this.ControlBox = false;
            this.Controls.Add(this.OptCls);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmOptions";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Picture Viewer Options";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button OptCls;
    }
}