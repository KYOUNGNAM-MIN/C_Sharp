﻿namespace WindowsFormsApplication2
{
    partial class frmOptions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnOptionsQuit = new System.Windows.Forms.Button();
            this.lblUserName = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.chkQuit = new System.Windows.Forms.CheckBox();
            this.chkStart = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.optBackgroundBlack = new System.Windows.Forms.RadioButton();
            this.optBackgroundWhite = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnOptionsQuit
            // 
            this.btnOptionsQuit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnOptionsQuit.Location = new System.Drawing.Point(355, 119);
            this.btnOptionsQuit.Name = "btnOptionsQuit";
            this.btnOptionsQuit.Size = new System.Drawing.Size(75, 23);
            this.btnOptionsQuit.TabIndex = 0;
            this.btnOptionsQuit.Text = "Quit";
            this.btnOptionsQuit.UseVisualStyleBackColor = true;
            this.btnOptionsQuit.Click += new System.EventHandler(this.btnOptionsQuit_Click);
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Location = new System.Drawing.Point(70, 76);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(88, 15);
            this.lblUserName.TabIndex = 1;
            this.lblUserName.Text = "User Name: ";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(153, 73);
            this.txtUserName.MaxLength = 10;
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(135, 25);
            this.txtUserName.TabIndex = 2;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(70, 127);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(82, 15);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "Password: ";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(153, 124);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(135, 25);
            this.textBox1.TabIndex = 4;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(355, 76);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(75, 23);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // chkQuit
            // 
            this.chkQuit.AutoSize = true;
            this.chkQuit.Location = new System.Drawing.Point(19, 29);
            this.chkQuit.Name = "chkQuit";
            this.chkQuit.Size = new System.Drawing.Size(89, 19);
            this.chkQuit.TabIndex = 6;
            this.chkQuit.Text = "종료확인";
            this.chkQuit.UseVisualStyleBackColor = true;
            // 
            // chkStart
            // 
            this.chkStart.AutoSize = true;
            this.chkStart.Location = new System.Drawing.Point(18, 64);
            this.chkStart.Name = "chkStart";
            this.chkStart.Size = new System.Drawing.Size(89, 19);
            this.chkStart.TabIndex = 7;
            this.chkStart.Text = "시작확인";
            this.chkStart.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkStart);
            this.groupBox1.Controls.Add(this.chkQuit);
            this.groupBox1.Location = new System.Drawing.Point(21, 172);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(131, 132);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // optBackgroundBlack
            // 
            this.optBackgroundBlack.AutoSize = true;
            this.optBackgroundBlack.Checked = true;
            this.optBackgroundBlack.Location = new System.Drawing.Point(18, 19);
            this.optBackgroundBlack.Name = "optBackgroundBlack";
            this.optBackgroundBlack.Size = new System.Drawing.Size(64, 19);
            this.optBackgroundBlack.TabIndex = 9;
            this.optBackgroundBlack.TabStop = true;
            this.optBackgroundBlack.Text = "Black";
            this.optBackgroundBlack.UseVisualStyleBackColor = true;
            // 
            // optBackgroundWhite
            // 
            this.optBackgroundWhite.AutoSize = true;
            this.optBackgroundWhite.Location = new System.Drawing.Point(18, 54);
            this.optBackgroundWhite.Name = "optBackgroundWhite";
            this.optBackgroundWhite.Size = new System.Drawing.Size(65, 19);
            this.optBackgroundWhite.TabIndex = 10;
            this.optBackgroundWhite.Text = "White";
            this.optBackgroundWhite.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.optBackgroundWhite);
            this.groupBox2.Controls.Add(this.optBackgroundBlack);
            this.groupBox2.Location = new System.Drawing.Point(171, 172);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(116, 131);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // frmOptions
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnOptionsQuit;
            this.ClientSize = new System.Drawing.Size(469, 381);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.btnOptionsQuit);
            this.DoubleBuffered = true;
            this.Name = "frmOptions";
            this.Text = "Picture Viewer Options";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnOptionsQuit;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.CheckBox chkQuit;
        private System.Windows.Forms.CheckBox chkStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton optBackgroundBlack;
        private System.Windows.Forms.RadioButton optBackgroundWhite;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}