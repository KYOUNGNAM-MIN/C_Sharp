﻿namespace ComboBox
{
    partial class ComboBox
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.cboColors = new System.Windows.Forms.ComboBox();
            this.btnAddColor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnDeleteColor = new System.Windows.Forms.Button();
            this.txtAddColor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cboColors
            // 
            this.cboColors.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboColors.FormattingEnabled = true;
            this.cboColors.Items.AddRange(new object[] {
            "BLACK",
            "BLUE",
            "GOLD",
            "GRAY",
            "GREEN",
            "RED",
            "YELLOW"});
            this.cboColors.Location = new System.Drawing.Point(90, 51);
            this.cboColors.Name = "cboColors";
            this.cboColors.Size = new System.Drawing.Size(507, 23);
            this.cboColors.Sorted = true;
            this.cboColors.TabIndex = 0;
            this.cboColors.SelectedIndexChanged += new System.EventHandler(this.cboColors_SelectedIndexChanged);
            // 
            // btnAddColor
            // 
            this.btnAddColor.Location = new System.Drawing.Point(385, 142);
            this.btnAddColor.Name = "btnAddColor";
            this.btnAddColor.Size = new System.Drawing.Size(135, 46);
            this.btnAddColor.TabIndex = 1;
            this.btnAddColor.Text = "색상 추가";
            this.btnAddColor.UseVisualStyleBackColor = true;
            this.btnAddColor.Click += new System.EventHandler(this.btnAddColor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "색상:";
            // 
            // btnDeleteColor
            // 
            this.btnDeleteColor.Location = new System.Drawing.Point(385, 203);
            this.btnDeleteColor.Name = "btnDeleteColor";
            this.btnDeleteColor.Size = new System.Drawing.Size(135, 46);
            this.btnDeleteColor.TabIndex = 3;
            this.btnDeleteColor.Text = "색상 삭제";
            this.btnDeleteColor.UseVisualStyleBackColor = true;
            this.btnDeleteColor.Click += new System.EventHandler(this.btnDeleteColor_Click);
            // 
            // txtAddColor
            // 
            this.txtAddColor.Location = new System.Drawing.Point(178, 155);
            this.txtAddColor.Name = "txtAddColor";
            this.txtAddColor.Size = new System.Drawing.Size(201, 25);
            this.txtAddColor.TabIndex = 4;
            // 
            // ComboBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 484);
            this.Controls.Add(this.txtAddColor);
            this.Controls.Add(this.btnDeleteColor);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddColor);
            this.Controls.Add(this.cboColors);
            this.Name = "ComboBox";
            this.Text = "Combo Box";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAddColor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDeleteColor;
        private System.Windows.Forms.TextBox txtAddColor;
        private System.Windows.Forms.ComboBox cboColors;
    }
}

