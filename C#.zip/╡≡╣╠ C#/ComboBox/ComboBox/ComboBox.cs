﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ComboBox
{
    public partial class ComboBox : Form
    {
        public ComboBox()
        {
            InitializeComponent();
        }

        private void btnAddColor_Click(object sender, EventArgs e)
        {
            
            if (String.IsNullOrEmpty(txtAddColor.Text))
            {
                MessageBox.Show("제대로 입력이 되지 않았습니다.");
                txtAddColor.Clear();
            }
            else
            {
                cboColors.Items.Add(txtAddColor.Text);
                MessageBox.Show("추가되었습니다.");
                txtAddColor.Clear();
            }
        }

        private void btnDeleteColor_Click(object sender, EventArgs e)
        {
            if (cboColors.Items.Count <= 5)
            {
                MessageBox.Show("최소 5개의 색이 필요합니다.");
            }
            else {
                MessageBox.Show("선택한 항목은 " + cboColors.SelectedItem + "이며, 이를 삭제합니다.");
                cboColors.Items.Remove(cboColors.SelectedItem);
            }
        }

        private void cboColors_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
