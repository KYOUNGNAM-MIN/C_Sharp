﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace List
{
    public partial class fclsLists : Form
    {
        public fclsLists()
        {
            InitializeComponent();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.Add("추가");
        }

        private void btnDeleteBottom_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.Remove("추가");
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.Clear();
        }

        private void btnShowItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("선택한 항목은 " + lstMyHobby.SelectedItem + "이며, 순서는" + lstMyHobby.SelectedIndex + "이다");
        }
    }
}
