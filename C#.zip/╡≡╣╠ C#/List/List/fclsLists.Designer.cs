﻿namespace List
{
    partial class fclsLists
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstMyHobby = new System.Windows.Forms.ListBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btnDeleteBottom = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnShowItem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstMyHobby
            // 
            this.lstMyHobby.FormattingEnabled = true;
            this.lstMyHobby.ItemHeight = 15;
            this.lstMyHobby.Items.AddRange(new object[] {
            "Arduino",
            "C",
            "C#",
            "C++",
            "CSS5",
            "HTML",
            "illustrator",
            "JAVA",
            "Photoshop",
            "Processing"});
            this.lstMyHobby.Location = new System.Drawing.Point(44, 57);
            this.lstMyHobby.Name = "lstMyHobby";
            this.lstMyHobby.Size = new System.Drawing.Size(578, 409);
            this.lstMyHobby.Sorted = true;
            this.lstMyHobby.TabIndex = 0;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(93, 489);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(114, 29);
            this.btnAddItem.TabIndex = 1;
            this.btnAddItem.Text = "Add";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // btnDeleteBottom
            // 
            this.btnDeleteBottom.Location = new System.Drawing.Point(239, 489);
            this.btnDeleteBottom.Name = "btnDeleteBottom";
            this.btnDeleteBottom.Size = new System.Drawing.Size(138, 28);
            this.btnDeleteBottom.TabIndex = 2;
            this.btnDeleteBottom.Text = "Delete 추가";
            this.btnDeleteBottom.UseVisualStyleBackColor = true;
            this.btnDeleteBottom.Click += new System.EventHandler(this.btnDeleteBottom_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(404, 489);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(106, 28);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "초기화";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnShowItem
            // 
            this.btnShowItem.Location = new System.Drawing.Point(535, 489);
            this.btnShowItem.Name = "btnShowItem";
            this.btnShowItem.Size = new System.Drawing.Size(107, 28);
            this.btnShowItem.TabIndex = 4;
            this.btnShowItem.Text = "선택";
            this.btnShowItem.UseVisualStyleBackColor = true;
            this.btnShowItem.Click += new System.EventHandler(this.btnShowItem_Click);
            // 
            // fclsLists
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 533);
            this.Controls.Add(this.btnShowItem);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDeleteBottom);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.lstMyHobby);
            this.Name = "fclsLists";
            this.Text = "Lists Example";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstMyHobby;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Button btnDeleteBottom;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnShowItem;
    }
}

