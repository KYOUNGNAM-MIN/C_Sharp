﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginSystem
{
    public partial class LoginSystem : Form
    {
        public LoginSystem()
        {
            InitializeComponent();
            picShowPicture.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void btnSelectPicture_Click(object sender, EventArgs e)
        {

            if (ofdSelectPicture.ShowDialog() == DialogResult.OK)
            {
                
                picShowPicture.Image = Image.FromFile(ofdSelectPicture.FileName);
                this.Text = string.Concat("Picture Viewer(" + ofdSelectPicture.FileName + ")");
            }
            
        
    }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if(txtName.Text.Equals("민경남") && txtPassword.Text.Equals("20162564"))
            {
                MessageBox.Show("민경남님. 로그인되었습니다.");
                btnSelectPicture.Enabled = true;
            }
            else
            {
                MessageBox.Show("로그인에 실패하였습니다.");
            }
        }
        private bool _moving;
        private Point _startlocation;
        private void picShowPicture_MouseDown(object sender, MouseEventArgs e)
        {
            _moving = true;
            _startlocation = e.Location;
        }

        private void picShowPicture_MouseMove(object sender, MouseEventArgs e)
        {
            if (_moving)
            {
                picShowPicture.Left += e.Location.X - _startlocation.X;
                picShowPicture.Top += e.Location.Y - _startlocation.Y;
            }
        }

        private void picShowPicture_MouseUp(object sender, MouseEventArgs e)
        {
            
            _moving = false;
        }
    }
}
