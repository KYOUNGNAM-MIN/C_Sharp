﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fclsList
{
    public partial class fclsList : Form
    {
        public fclsList()
        {
            InitializeComponent();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.Add("음악");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.RemoveAt(0);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstMyHobby.Items.Clear();
        }
    }
}
